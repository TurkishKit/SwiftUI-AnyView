//
//  ContentView.swift
//  Any View
//
//  Created by Ufuk Köşker on 3.09.2020.
//  Copyright © 2020 Ufuk Köşker. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    private var isLoggedIn: Bool = true
    
    var body: some View {
        if isLoggedIn {
            return AnyView(
                Image(systemName: "hand.thumbsup.fill")
                .resizable()
                .frame(width: 100, height: 100)
            )
        } else {
            return AnyView(Text("Giriş Yapmadı"))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
